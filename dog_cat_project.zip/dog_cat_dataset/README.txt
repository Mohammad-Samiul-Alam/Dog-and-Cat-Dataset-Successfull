Dog/Cat YOLO project
====================
1. Put ALL your cat & dog images in: dog_cat_dataset/dog_cat/train/images/
   (images only - no label files needed)
2. Upload the "dog_cat_dataset" folder to Google Drive > MyDrive
3. Open Train_Dog_Cat_8steps_fixed.ipynb in Colab and run cells 1-8 in order.

Cell 4 automatically creates:
  - YOLO labels (.txt boxes) for every image
  - train / valid (15%) / test (10%) folders
  - data.yaml
Tip: file names containing 'cat' or 'dog' (e.g. cat_001.jpg) make labeling more accurate.
